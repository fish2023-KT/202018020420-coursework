package org.example;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;

import org.junit.Before;

import java.io.ByteArrayInputStream;
import java.io.InputStream;


import static org.junit.Assert.*;


public class Junit {
    private NumberleModel model;
    private NumberleView view;
    @Before
    public void Setup(){
        model=new NumberleModel();
    }
    @Test
    public void TestNumber(){
      model.setTargetword("2*4=4*2");
      model.input("2*4=4*2");
      assertEquals("2*4=4*2",model.getTargetWord());
      assertTrue(model.Gamewon);

    }
    @Test
    public void ProcessInput(){
        model.StartGame("");
        assertFalse(model.processInput(""));
        assertFalse(model.processInput("3*2=2*8"));
        assertFalse(model.isGameWon());
    }
    @Test
    public void Remove_EmptyGuess() {
        model.StartGame("");
        assertEquals(0, model.getCurrentGuess().length());
    }

    @Test
    public void StartNewGame() {
        model.StartGame("");
        String oldTargetWord = model.getTargetWord();
        model.startNewGame(oldTargetWord);
        assertNotEquals(oldTargetWord, model.getTargetWord());
    }



    @Test
    public void testProcessInput_InvalidEquation() {
        model.setFlag3(true);
        model.StartGame("");
        assertFalse(model.processInput("1+2=2+3"));
        assertFalse(model.isGameWon());
    }


}

