package org.example;

import java.io.File;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.io.FileNotFoundException;


public class NumberleModel extends java.util.Observable implements INumberleModel{

    private String Word;
    public ArrayList<String> List=new ArrayList<>();
    public int remainAttempts=6  ;
    public boolean Gamewon;
    public boolean Flag1=false;
    public boolean Flag2=false ;
    public boolean Flag3;

    public String Formal_World="3+4-2=5";

    private StringBuilder CurrentGuess;


    //Start new game you should know this function just from txt file to select the words
    //which is random to select
    public void StartGame(String oldTarget){
        this.FileRead();
        if (List == null || List.isEmpty()) {
            System.out.println("The list is null or empty. Please check and fix it.");
            return;
        }
        if (oldTarget != null && !oldTarget.isEmpty()) {
            this.List.removeIf(s -> s.equals(oldTarget));
        }
        this.FileRead();
        Random random = new Random();
//        System.out.println(List);
        int index = random.nextInt(List.size());

        if (Flag1){
            System.out.println("This is not the correct answer.");
        }

        if (Flag2){
            System.out.println(getTargetWord());
        }

        if (Flag3){
            Word = Formal_World;
        } else {
            Word = List.get(index);
        }

        CurrentGuess = new StringBuilder(Word.length());
        remainAttempts = Attempt;
        Gamewon = false;

        setChanged();
        notifyObservers();
    }

    public boolean ProcessInput(String input){

        assert input.length() <=7 : "Input length should be <= 7";
        if (input.length() < 7){
            return false;
        }
        CurrentGuess = new StringBuilder(input);

        if (CurrentGuess.toString().equals(Word)) {
            Gamewon = true;
        }
        setChanged();
        notifyObservers();
        return Gamewon;
    }

    public boolean input(String input){
        assert input.length() <=7 : "Input length should be <= 7";
        if (input.length() < 7){
            System.out.println("input length must =7");
        }
        CurrentGuess = new StringBuilder(input);


        if (CurrentGuess.toString().equals(Word)) {
            Gamewon = true;
        }
        else {
            remainAttempts--;
        }
       return  Gamewon;
        }





    public  void FileRead(){
        try {
            File file=new File("./equations.txt");
            assert file.exists():"File should be exists";
            Scanner scanner =new Scanner(file);

            while(scanner.hasNextLine()){
                this.List.add(scanner.nextLine());

            }
            scanner.close();

        } catch (FileNotFoundException e) {
            System.out.println("File can not read,please try to fix it  ");
        }

    }


    @Override
    public boolean processInput(String input) {
        return ProcessInput(input);
    }

    @Override
    public boolean isGameOver() {
        assert remainAttempts >= 0 : "remainAttempts should be non-negative";
        return remainAttempts <= 0 || Gamewon ;
    }

    @Override
    public boolean isGameWon() {
        return Gamewon;
    }



    @Override
    public void setFlag(boolean flag2) {
        this.Flag2=flag2;
    }
    @Override
    public void setFlag3(boolean flag3) {
        this.Flag3=flag3;
    }




    @Override
    public void setTargetword(String targetword) {
        assert targetword != null : "targetword should not be null";
        assert targetword.length() >= 7 : "targetword length should be >= 7";
        this.Word=targetword;
    }

    @Override
    public String getTargetWord() {
        return Word;
    }

    @Override
    public StringBuilder getCurrentGuess() {
        return CurrentGuess;
    }

    @Override
    public int getRemainingAttempts() {
        assert remainAttempts >= 0 : "remainAttempts should be non-negative";
        return remainAttempts;
    }

    @Override
    public void setRemainingAttempts(int val) {
        assert val >= 0 : "val should be non-negative";
        remainAttempts = val;


    }

    @Override
    public boolean startNewGame(String oldTarget) {
        StartGame(oldTarget);
        return false;
    }




//    @Override
//    public void Delete() {
//
//        if (CurrentGuess.length()>0){
//            CurrentGuess.deleteCharAt(CurrentGuess.length()-1);
//            setChanged();
//            notifyObservers();
//        }
//    }


}
