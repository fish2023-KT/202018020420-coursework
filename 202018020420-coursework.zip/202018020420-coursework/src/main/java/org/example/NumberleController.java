package org.example;

public class NumberleController {


    private INumberleModel model;

    public NumberleController(INumberleModel model) {
        this.model = model;
    }
    public int getRemainingAttempts() {
        return model.getRemainingAttempts();
    }
    public void startNewGame() {
        model.startNewGame("");
    }


    public void SetFlag(Boolean Flag3){
        model.setFlag3(Flag3);
        if (Flag3){
       model.setTargetword("3*2+1=7");
        }

    }
    public void setflag1(Boolean flag){
        model.setFlag(flag);;
        System.out.println("error,the equation is not valid,this will not count as one of tires. so you have "+""+getRemainingAttempts()+" "+"chance ");


    }
    public void setFlag2(Boolean Flag){

        if (Flag){
            System.out.println(getTargetWord());
        }

    }
    public String getTargetWord() {
        return model.getTargetWord();
    }
    public void setRemainingAttempts(int val) {
        model.setRemainingAttempts(val);
    }
    public void processInput(String input) {
       model.processInput(input);
    }
    public boolean isGameOver() {
        return model.isGameOver();
    }
    public boolean isGameWon() {
        return model.isGameWon();
    }


}
