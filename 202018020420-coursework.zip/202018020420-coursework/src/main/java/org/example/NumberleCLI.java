package org.example;
import java.util.Scanner;
import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;



public class NumberleCLI {
    private static final String GREEN = "\u001B[32m";
    private static final String YELLOW = "\u001B[33m";

    private static final String White = "\u001B[36m";
    private static final String GRAY = "\u001B[90m";


    private static final INumberleModel model = new NumberleModel();
    private static final Scanner scanner = new Scanner(System.in);

    private static void GameStart() {
        while (!model.isGameOver()) {
            GameStatue();
            String input = InputInformation();
            if (input.length()<7){
                System.out.println("the input length is too short ");
            }
            boolean containsOperator = false; // Flag to check if an operator is present

            for (char c : input.toCharArray()) {
                if ("+-*/".indexOf(c) != -1) {
                    containsOperator = true; // Set flag if an operator is found
                    break;
                }
            }
            boolean equal=input.contains("=");

            boolean containsMultiple=input.contains("+-*/");
            boolean containMultiples=input.contains("+-/");
            if (!equal){

                System.out.println("no equal please try again ");
            } else if (containMultiples||containsMultiple) {
                System.out.println("the Multiple operator");
            }else if (!containsOperator){
                System.out.println("at least one operator");
            }
            if  (input.length()==7) {
                  if (correct(input)){
                      boolean correct = model.input(input);
                      ColoredInput(input, model.getTargetWord());
                      if (correct) {
                          break;
                      }
                  }

            }


        }
        if (model.isGameWon()) {
            System.out.println("wow! you won the game ");
        } else {
            System.out.println("Game over ! your lose the game  !");
            System.out.println("The right answer is " + model.getTargetWord());
        }
    }

    private static void printCategories() {

        System.out.println("operator: + - * / =");
         System.out.println("number: 0 1 2 3 4 5 6 7 8 9");

    }

    private static String InputInformation() {
        System.out.print("please enter your guess: ");
        return scanner.nextLine();
    }
    private static void GameStatue() {
//        System.out.println("the target equation: " + model.getTargetWord());
        System.out.println("you  have : " + model.getRemainingAttempts()+" "+"chances");
        System.out.println("your input guess is : " + model.getCurrentGuess());
        printCategories();
    }
    private static void ColoredInput(String input, String target) {

        StringBuilder SE = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (i < target.length() && c == target.charAt(i)) {
                SE.append(GREEN).append(c);
            } else if (target.contains(String.valueOf(c))) {
                SE.append(YELLOW).append(c);
            } else {
                SE.append(GRAY).append(c);
            }
        }
        SE.append(White);
        System.out.println(SE.toString());
    }
    private static boolean correct(String input) {
        String[] EQUAL = input.split("=");
        if (EQUAL.length != 2) {
            return false;
        }
        Expression expLeft = new ExpressionBuilder(EQUAL[0].trim()).build();
        double leftResult = expLeft.evaluate();
        Expression expRight = new ExpressionBuilder(EQUAL[1].trim()).build();
        double rightResult = expRight.evaluate();
        if (leftResult!=rightResult){
            System.out.println("the left side is not equal right side ");
        }
        return Double.compare(leftResult, rightResult) == 0;
    }
    public static void main(String[] args) {
        model.startNewGame("");
        GameStart();
    }
}
