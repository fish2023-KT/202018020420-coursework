package org.example;


import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.Observable;
import java.util.Observer;


import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;


public class NumberleView extends JFrame implements Observer {
    private JPanel Panel;//game panel
    private JLayeredPane layeredPane;
    private NumberleController controller;// Controller
    private final INumberleModel model;// Model
    public JButton button[][] = new JButton[6][7]; // Game buttons
    private JTextField inputTextField;
    private int Row = 0;

    public static final int ROWS = 6;// Total rows
    public static final int COLS = 7;// Total columns
    public static final int MAX_INPUT_LENGTH = 7;// Maximum length of input text field
    private static final Color CORRECT_COLOR = Color.GREEN; // Correct color
    //The entered text contains letters but in the wrong order
    private static final Color INCORRECT_COLOR = Color.YELLOW;
    private final Color defaultColor = UIManager.getColor("Button.background");// Default button color
    //
    private JPanel row1;// First row panel
    private JPanel row2;//  Second row panel


    public NumberleView(INumberleModel model, NumberleController controller) {
        // Parameter validation
        assert model != null; // Ensure model parameter is not null
        assert controller != null; // Ensure controller parameter is not null

        // Assigning controller and model
        this.controller = controller; // Assign controller parameter to the controller field
        this.model = model; // Assign model parameter to the model field

        // Start new game
        controller.startNewGame(); // Invoke startNewGame method of the controller

        // Initialize GUI components
        initialize(); // Call the initialize method to set up the GUI components

        // Show game start reminder
        showGameStartReminder(); // Display a reminder or message indicating the game has started

        // Register view as observer to model
        ((NumberleModel) this.model).addObserver(this); // Register this view as an observer to the model

        // Set view for controller
//        this.controller.setView(this); // Set this view instance as the view for the controller

        // Update view with initial model state
        update((NumberleModel) this.model, null); // Call update method to synchronize view with initial model state
    }

    public void initialize() {

        // Set the look and feel of the user interface to MetalLookAndFeel
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Set the title of the frame
        setTitle("Game");

        // Set default close operation to exit the application when the frame is closed
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set the frame size to 800x800 pixels
        setSize(750, 750);
        setLocationRelativeTo(null);
        // Make the frame non-resizable
        setResizable(false);

        // Set the layout of the frame to BorderLayout
        setLayout(new BorderLayout());

        // Create a panel with a 6x7 grid layout for buttons
        Panel = new JPanel(new GridLayout(6, 7));

        // Create buttons and add them to the panel
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                button[i][j] = new JButton("");
                button[i][j].setPreferredSize(new Dimension(100, 100));
                Panel.add(button[i][j]);
            }
            // Add the panel to the frame's center position
            add(Panel, BorderLayout.CENTER);
            Panel.setVisible(true);
        }

        // Create an input panel with a text field
        JPanel inputPanel = new JPanel();
        inputTextField = new JTextField(7);
        inputPanel.add(inputTextField);
        add(inputPanel, BorderLayout.NORTH);
        inputPanel.setVisible(false);

        // Get text from input text field
        String input = inputTextField.getText();

        // Assert that input text field is not null or empty
        assert (input) != null & !input.isEmpty();

        // Create a keyboard panel with numeric buttons and operator buttons
        JPanel keyBoardPanel = new JPanel();
        keyBoardPanel.setLayout(new BoxLayout(keyBoardPanel, BoxLayout.Y_AXIS));
        row1 = new JPanel();
        row1.setLayout(new FlowLayout());
        for (int i = 1; i <= 9; i++) {
            JButton button = new JButton(Integer.toString(i));
            button.setFont(new Font("Serif", Font.PLAIN, 30));
            button.addActionListener(new ButtonClickListener());
            row1.add(button);
        }
        JButton zeroButton = new JButton("0");
        zeroButton.setFont(new Font("Serif", Font.PLAIN, 30));
        zeroButton.addActionListener(new ButtonClickListener());
        row1.add(zeroButton);

        row2 = new JPanel();
        row2.setLayout(new FlowLayout());
        String[] operators = {"Remove", "+", "-", "*", "/", "=", "Enter"};
        for (String operator : operators) {
            JButton button = new JButton(operator);
            button.setFont(new Font("Serif", Font.PLAIN, 30));
            button.addActionListener(new ButtonClickListener());
            row2.add(button);
        }
        keyBoardPanel.add(row1);
        keyBoardPanel.add(row2);

        // Add the keyboard panel to the frame's south position
        add(keyBoardPanel, BorderLayout.SOUTH);

        // Create a button panel with various control buttons
        JPanel ButtonPanel = new JPanel();
        JButton Information = new JButton("How to play");
        ButtonPanel.add(Information);

// Add the button panel to the frame's north position
        add(ButtonPanel, BorderLayout.WEST);

        JButton FixFormual = new JButton("Fixed_Formula");
        JButton display = new JButton("Display");


        display.addActionListener(e -> {
            display();
        });

        // Add action listeners to control buttons
        FixFormual.addActionListener(e -> {
            Fixed();
        });

        Information.addActionListener(e -> {
            HowtoPlayGame();
        });


        // Add buttons to the button panel
        ButtonPanel.add(Information);
        ButtonPanel.add(FixFormual);
        ButtonPanel.add(display);


        // Add the button panel to the frame's north position
        add(ButtonPanel, BorderLayout.NORTH);

        // Make the frame visible
        setVisible(true);

        // Call the change method
        change();
    }

    public void Fixed() {
        controller.SetFlag(true);
        System.out.println(controller.getTargetWord());
    }

    /**
     * Removes all components from row2 panel and replaces them with operator buttons in a specific order.
     * This method is called when the "Swap" button is clicked.
     */

    public void display() {
        controller.setFlag2(true);
    }

    /**
     * Updates the buttons based on the input text.
     * This method is called when there is a change in the input text field.
     */
    public void change() {
        String input = inputTextField.getText();
        updateButtonsFromInput(input);
    }


    /**
     * ActionListener implementation for handling button clicks.
     */
    private class ButtonClickListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JButton source = (JButton) e.getSource();
            String buttonText = source.getText();
            switch (buttonText) {
                case "Remove":
                    clearDisplay();
                    break;
                case "Enter":
                    Enter();

                    break;
                default:
                    if (inputTextField.getText().length() < MAX_INPUT_LENGTH) {
                        updateDisplay(buttonText);
                        updateButtonsFromInput(inputTextField.getText());
                    }
                    controller.isGameOver();
            }
        }
    }

    /**
     * Updates the color and text of buttons based on the target word and user input.
     *
     * @param target The target word as an array of characters.
     * @param input  The user input as a string.
     */
    private void updateButtonsFromTarget(char[] target, String input) {
        char[] userInput = input.toCharArray();

        for (int col = 0; col < 7; col++) {

            char targetChar = target[col];
            char inputChar = userInput[col];

            if (targetChar == inputChar) {
                button[Row][col].setBackground(Color.GREEN);
            } else if (new String(target).indexOf(inputChar) != -1) {
                button[Row][col].setBackground(Color.ORANGE);
            } else {
                button[Row][col].setBackground(Color.GRAY);
            }

            button[Row][col].setText(String.valueOf(inputChar));


            String buttonText = button[Row][col].getText();


            for (Component component : row1.getComponents()) {
                if (component instanceof JButton) {
                    JButton keyboardButton = (JButton) component;
                    if (keyboardButton.getText().equals(buttonText)) {
                        if (targetChar == inputChar) {
                            keyboardButton.setBackground(Color.GREEN);
                        } else if (new String(target).indexOf(inputChar) != -1) {
                            keyboardButton.setBackground(Color.ORANGE);
                        } else {
                            keyboardButton.setBackground(Color.GRAY);
                        }
                        break;
                    }
                }
            }


            for (Component component : row2.getComponents()) {
                if (component instanceof JButton) {
                    JButton keyboardButton = (JButton) component;
                    if (keyboardButton.getText().equals(buttonText)) {
                        if (targetChar == inputChar) {
                            keyboardButton.setBackground(Color.GREEN);
                        } else if (new String(target).indexOf(inputChar) != -1) {
                            keyboardButton.setBackground(Color.ORANGE);
                        } else {
                            keyboardButton.setBackground(Color.GRAY);
                        }
                        break;
                    }
                }
            }
        }
    }


    /**
     * Updates the text of buttons based on the user input.
     *
     * @param input The user input as a string.
     */
    private void updateButtonsFromInput(String input) {
        int rowIndex = Row;

        int colIndex = 0;
        char[] chars = input.toCharArray();

        for (char c : chars) {
            if (Character.isDigit(c) || "+-*/=".indexOf(c) != -1) {
                if (colIndex < 7) {
                    button[rowIndex][colIndex].setText(String.valueOf(c));
                    colIndex++;

                }
            }
        }
        for (int clearIndex = colIndex; clearIndex < 7; clearIndex++) {
            button[rowIndex][clearIndex].setText("");
        }


    }

    /**
     * Handles the action when the "Enter" button is clicked.
     */
    public void Enter() {
        String input = inputTextField.getText();
        // Check if input length is less than 7
        if (input.length() < 7) {
            controller.setflag1(true);
            TooShort();
            return; // Return to avoid further processing
        }

        boolean containsOperator = false; // Flag to check if an operator is present

        for (char c : input.toCharArray()) {
            if ("+-*/".indexOf(c) != -1) {
                containsOperator = true; // Set flag if an operator is found
                break;
            }
        }


        if (input.length() == 7) {
            boolean containsEquals = input.contains("=");
            boolean containsMultiple = input.contains("+-*/");
            boolean containMultiples = input.contains("+-/");
            boolean containMultipless = input.contains("+-*");
            boolean contains = input.contains("+=++");

            if (!containsEquals) {
                NoEqualSign();
            } else if (!containsOperator) {
                Symobol();
            } else if (containsMultiple || containMultiples || containMultipless) {
                MultiplyOperator();

            } else if (contains) {
                MultiplyOperator();
            } else {
                boolean isCorrect = validateEquation(input);
                if (isCorrect) {
                    char[] target = controller.getTargetWord().toCharArray();
                    validateEquation(input);

                    controller.setRemainingAttempts(controller.getRemainingAttempts() - input.length() / 7);

                    updateButtonsFromInput(input); // Update buttons based on the input4
                    updateButtonsFromTarget(target, input);
                    Row++;

                    if (Row > 5) {
                        Row = 0;
                    }
                    controller.processInput(input);

                    inputTextField.setText(""); // Clear the input text field
                    if (controller.getRemainingAttempts() == 0) {
                        Youlost();
                    }
                } else {

                    NotEqual();
                }
            }
        }

    }


    /**
     * Validates the equation provided by the user.
     *
     * @param input The equation input by the user.
     * @return True if the equation is valid, false otherwise.
     */
    private boolean validateEquation(String input) {
        String[] parts = input.split("="); // Split the input into left and right sides of the equation
        if (parts.length != 2) {
            return false; // Return false if the equation doesn't contain exactly one equals sign
        }

        // Evaluate the left side of the equation
        Expression expLeft = new ExpressionBuilder(parts[0].trim()).build();
        double leftResult = expLeft.evaluate();

        // Evaluate the right side of the equation
        Expression expRight = new ExpressionBuilder(parts[1].trim()).build();
        double rightResult = expRight.evaluate();

        // Compare the results of the left and right sides of the equation
        return Double.compare(leftResult, rightResult) == 0;
    }


    /**
     * Clears the display by removing the last character from the input text field.
     */
    public void clearDisplay() {
        String currentText = inputTextField.getText();
        if (!currentText.isEmpty()) {
            // Remove the last character from the current text
            String newText = currentText.substring(0, currentText.length() - 1);
            inputTextField.setText(newText);
            // Update buttons based on the new input text
            updateButtonsFromInput(newText);
        }
    }


    /**
     * Updates the display by appending the given text to the input text field.
     * If the length of the resulting text exceeds 7 characters, it truncates the text appropriately.
     *
     * @param text The text to be added to the input text field.
     */
    public void updateDisplay(String text) {
        // Check if adding the text will exceed the maximum length
        if (inputTextField.getText().length() + text.length() > 7) {
            // Truncate the text to fit within the maximum length
            text = text.substring(0, 7 - inputTextField.getText().length());
        }
        // Append the text to the input text field
        inputTextField.setText(inputTextField.getText() + text);
    }


    /**
     * Displays a reminder frame indicating that the input is too short.
     * The reminder frame is displayed for 2 seconds before automatically closing.
     */
    public void TooShort() {
        // Create a reminder frame
        JFrame reminderFrame = new JFrame("reminder");
        reminderFrame.setBounds(625, 300, 400, 200);
        reminderFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create a label for the reminder message
        JLabel reminderLabel = new JLabel("Too Short !");
        reminderLabel.setFont(new Font("Serif", Font.BOLD, 25));
        reminderLabel.setHorizontalAlignment(JLabel.CENTER);

        // Create a panel to hold the reminder label
        JPanel reminderPanel = new JPanel(new BorderLayout());
        reminderPanel.add(reminderLabel, BorderLayout.CENTER);
        reminderFrame.getContentPane().add(reminderPanel);

        // Make the reminder frame visible
        reminderFrame.setVisible(true);

        // Set a timer to automatically close the reminder frame after 2 seconds
        Timer timer = new Timer(2000, e -> {
            reminderFrame.dispose();
        });
        timer.setRepeats(false);
        timer.start();
    }

    /**
     * Displays a reminder frame indicating that there must be at least one mathematical symbol
     * +- * / The reminder frame is displayed for 2 seconds before automatically closing.
     */

    public void MultiplyOperator() {
        // Create a reminder frame
        JFrame reminderFrame = new JFrame("reminder");
        reminderFrame.setBounds(625, 300, 400, 200);
        reminderFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create a label for the reminder message
        JLabel reminderLabel = new JLabel("Multiple math symbols in a row ");
        reminderLabel.setFont(new Font("Serif", Font.BOLD, 25));
        reminderLabel.setHorizontalAlignment(JLabel.CENTER);

        // Create a panel to hold the reminder label
        JPanel reminderPanel = new JPanel(new BorderLayout());
        reminderPanel.add(reminderLabel, BorderLayout.CENTER);
        reminderFrame.getContentPane().add(reminderPanel);

        // Make the reminder frame visible
        reminderFrame.setVisible(true);

        // Set a timer to automatically close the reminder frame after 2 seconds
        Timer timer = new Timer(2000, e -> {
            reminderFrame.dispose();
        });
        timer.setRepeats(false);
        timer.start();
    }

    /**
     * Displays a reminder frame indicating that there
     * they must be at least one sign
     */
    public void Symobol() {
        // Create a reminder frame
        JFrame reminderFrame = new JFrame("reminder");
        reminderFrame.setBounds(625, 300, 400, 200);
        reminderFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create a label for the reminder message
        JLabel reminderLabel = new JLabel("There must be at least one sign +-*/ !");
        reminderLabel.setFont(new Font("Serif", Font.BOLD, 25));
        reminderLabel.setHorizontalAlignment(JLabel.CENTER);

        // Create a panel to hold the reminder label
        JPanel reminderPanel = new JPanel(new BorderLayout());
        reminderPanel.add(reminderLabel, BorderLayout.CENTER);
        reminderFrame.getContentPane().add(reminderPanel);

        // Make the reminder frame visible
        reminderFrame.setVisible(true);

        // Set a timer to automatically close the reminder frame after 2 seconds
        Timer timer = new Timer(2000, e -> {
            reminderFrame.dispose();
        });
        timer.setRepeats(false);
        timer.start();
    }

    /**
     * Displays a reminder frame explaining how to play the game.
     * The reminder frame contains instructions on how to guess the hidden mathematical equation in 6 tries
     * and how the color of the tiles changes to show the proximity to the correct solution.
     * The reminder frame is displayed until closed by the user.
     */
    public void HowtoPlayGame() {
        // Create a frame to display the instructions
        JFrame reminderFrame = new JFrame("How to play");
        reminderFrame.setBounds(420, 150, 850, 850);
        reminderFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create a text area to display the instructions
        JTextArea textArea = new JTextArea();
        textArea.setLineWrap(true); // Enable automatic line wrapping
        textArea.setWrapStyleWord(true);
        textArea.setText("Game Rules. The aim of the game is to guess the hidden mathematical equation and the color of the tiles within 6 attempts. Players need to input a mathematical equation and then make guesses on the correct equation and the color of the tiles based on the hints provided. For example, if the hidden equation is 5 + 75 = 40, and the player inputs 5 + 52 = 10, then according to whether the positions and numbers are correct, certain parts of the tiles will turn green to indicate the correct parts."

        );

        // Set font and size for the text area
        textArea.setFont(new Font("Serif", Font.ROMAN_BASELINE, 30));

        // Create a panel to hold the text area
        JPanel reminderPanel = new JPanel(new BorderLayout());
        reminderPanel.add(textArea, BorderLayout.CENTER);
        reminderFrame.getContentPane().add(reminderPanel);

        // Make the reminder frame visible
        reminderFrame.setVisible(true);
    }


    /**
     * Displays a reminder frame indicating that the left side of the equation is not equal to the right side.
     * Displays a reminder frame indicating that the left side of the equation is not equal to the right side.
     */
    public void NotEqual() {
        // Create a frame to display the reminder
        JFrame reminderFrame = new JFrame("reminder");
        reminderFrame.setBounds(625, 300, 500, 400);
        reminderFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create a label to display the reminder message
        JLabel reminderLabel = new JLabel("The left side is not equal to the right");
        reminderLabel.setFont(new Font("Serif", Font.BOLD, 25));
        reminderLabel.setHorizontalAlignment(JLabel.CENTER);

        // Create a panel to hold the label
        JPanel reminderPanel = new JPanel(new BorderLayout());
        reminderPanel.add(reminderLabel, BorderLayout.CENTER);
        reminderFrame.getContentPane().add(reminderPanel);

        // Make the reminder frame visible
        reminderFrame.setVisible(true);

        // Close the reminder frame after a delay
        Timer timer = new Timer(2000, e -> {
            reminderFrame.dispose();
        });
        timer.setRepeats(false);
        timer.start();
    }

    /**
     * Displays a reminder frame indicating the game start and prompts the user to guess the first equation.
     * The reminder frame is displayed until closed by the user.
     */
    private void showGameStartReminder() {
        // Create a frame to display the reminder
        JFrame reminderFrame = new JFrame("reminder");
        reminderFrame.setBounds(625, 300, 450, 300);
        reminderFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create a label to display the reminder message
        JLabel reminderLabel = new JLabel("Guess the first equation!");
        reminderLabel.setFont(new Font("Serif", Font.BOLD, 25));
        reminderLabel.setHorizontalAlignment(JLabel.CENTER);

        // Create a panel to hold the label
        JPanel reminderPanel = new JPanel(new BorderLayout());
        reminderPanel.setBackground(Color.RED);
        reminderPanel.add(reminderLabel, BorderLayout.CENTER);
        reminderFrame.getContentPane().add(reminderPanel);

        // Make the reminder frame visible
        reminderFrame.setVisible(true);

        // Close the reminder frame after a delay
        Timer timer = new Timer(2000, e -> {
            reminderFrame.dispose();
        });
        timer.setRepeats(false);
        timer.start();
    }

    /**
     * Displays a reminder frame indicating that there is no equal (=) sign in the input.
     * The reminder frame is displayed until closed by the user.
     */
    public void NoEqualSign() {
        // Create a frame to display the reminder
        JFrame reminderFrame = new JFrame("reminder");
        reminderFrame.setBounds(625, 300, 400, 200);
        reminderFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create a label to display the reminder message
        JLabel reminderLabel = new JLabel("No equal (=) sign!");
        reminderLabel.setFont(new Font("Serif", Font.BOLD, 25));
        reminderLabel.setHorizontalAlignment(JLabel.CENTER);

        // Create a panel to hold the label
        JPanel reminderPanel = new JPanel(new BorderLayout());
        reminderPanel.add(reminderLabel, BorderLayout.CENTER);
        reminderFrame.getContentPane().add(reminderPanel);

        // Make the reminder frame visible
        reminderFrame.setVisible(true);

        // Close the reminder frame after a delay
        Timer timer = new Timer(2000, e -> {
            reminderFrame.dispose();
        });
        timer.setRepeats(false);
        timer.start();
    }

    /**
     * Displays a reminder frame indicating that the player has lost the game.
     * Provides an option to replay the game.
     */
    public void Youlost() {
        // Create a frame to display the reminder
        JFrame reminderFrame = new JFrame("reminder");
        reminderFrame.setBounds(625, 300, 400, 200);
        reminderFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create a button for replaying the game
        Button Replay = new Button("Replay");
        Replay.addActionListener(e -> {
            controller.startNewGame();
            System.out.println("you replay the game  so the number become " + " " + controller.getTargetWord());
            for (int row = 0; row < ROWS; row++) {
                for (int col = 0; col < COLS; col++) {
                    button[row][col].setText("");
                    button[row][col].setBackground(defaultColor);
                }
            }

            // Enable buttons for input
            for (Component component : row1.getComponents()) {
                if (component instanceof JButton) {
                    component.setEnabled(true);
                    component.setBackground(defaultColor);
                }
            }
            // Enable operator buttons
            for (Component component : row2.getComponents()) {
                if (component instanceof JButton) {
                    component.setEnabled(true);
                    component.setBackground(defaultColor);
                }
            }
            // Close the reminder frame
            reminderFrame.dispose();
        });
        Replay.setBounds(10, 20, 10, 10);

        // Create a label to display the reminder message
        JLabel reminderLabel = new JLabel("You lost!");
        reminderLabel.setFont(new Font("Serif", Font.BOLD, 25));
        reminderLabel.setHorizontalAlignment(JLabel.CENTER);

        // Create a panel to hold the label and replay button
        JPanel reminderPanel = new JPanel(new BorderLayout());
        reminderPanel.add(reminderLabel, BorderLayout.CENTER);
        reminderPanel.add(Replay, BorderLayout.NORTH);

        // Add the panel to the reminder frame
        reminderFrame.getContentPane().add(reminderPanel);

        // Make the replay button and reminder frame visible
        Replay.setVisible(true);
        reminderFrame.setVisible(true);
    }

    /**
     * Displays a reminder frame indicating that the player has won the game.
     * Provides an option to replay the game.
     */
    public void Youwon() {
        // Create a frame to display the reminder
        JFrame reminderFrame = new JFrame("reminder");
        reminderFrame.setBounds(625, 300, 400, 200);
        reminderFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create a button for restarting the game
        Button Restart = new Button("Replay");
        Restart.addActionListener(e -> {
            Row = 0;
            // Reset the game board
            for (int row = 0; row < ROWS; row++) {
                for (int col = 0; col < COLS; col++) {
                    button[row][col].setText("");
                    button[row][col].setBackground(defaultColor);
                }
            }
            // Enable buttons for input
            for (Component component : row1.getComponents()) {
                if (component instanceof JButton) {
                    component.setEnabled(true);
                    component.setBackground(defaultColor);
                }
            }
            // Enable operator buttons
            for (Component component : row2.getComponents()) {
                if (component instanceof JButton) {
                    component.setEnabled(true);
                    component.setBackground(defaultColor);
                }
            }
            // Close the reminder frame
            reminderFrame.dispose();
        });
        Restart.setBounds(10, 20, 10, 10);

        // Create a label to display the reminder message
        JLabel reminderLabel = new JLabel("You won!");
        reminderLabel.setFont(new Font("Serif", Font.BOLD, 25));
        reminderLabel.setHorizontalAlignment(JLabel.CENTER);

        // Create a panel to hold the label and restart button
        JPanel reminderPanel = new JPanel(new BorderLayout());
        reminderPanel.add(reminderLabel, BorderLayout.CENTER);
        reminderPanel.add(Restart, BorderLayout.NORTH);

        // Add the panel to the reminder frame
        reminderFrame.getContentPane().add(reminderPanel);

        // Make the restart button and reminder frame visible
        Restart.setVisible(true);
        reminderFrame.setVisible(true);
    }

    @Override
/**
 * update the GUI ,If the view is change the observable will notice changed
 *
 */
    public void update(Observable o, Object arg) {


        if (controller.isGameOver()) {
            if (controller.isGameWon()) {
                Youwon();
                controller.startNewGame();
                System.out.println("The new number is" + " " + controller.getTargetWord());

            }

            for (Component component : row1.getComponents()) {
                if (component instanceof JButton) {
                    component.setEnabled(false);
                }
            }
            for (Component component : row2.getComponents()) {
                if (component instanceof JButton) {
                    component.setEnabled(false);
                }
            }
        }
    }
}
