package org.example;


public interface INumberleModel{
    int Attempt = 6;


    void StartGame(String oldTarget);
    boolean processInput(String input);
    boolean isGameOver();
    boolean isGameWon();

    void setFlag3(boolean flag3);

    boolean input(String input);
    void setFlag(boolean flag1);
    void setTargetword(String targetword);
    String getTargetWord();
    StringBuilder getCurrentGuess();
    int getRemainingAttempts();
    void setRemainingAttempts(int val);
    boolean startNewGame(String oldTarget);


}



